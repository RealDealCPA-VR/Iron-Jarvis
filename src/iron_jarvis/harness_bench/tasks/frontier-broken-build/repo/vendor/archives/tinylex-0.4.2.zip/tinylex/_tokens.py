"""The tokenizer."""
import re
from collections import namedtuple

Token = namedtuple("Token", ["kind", "text", "href"], defaults=[""])

_PATTERN = re.compile(
    r"`(?P<code>[^`]+)`"
    r"|\*\*(?P<strong>[^*]+)\*\*"
    r"|\*(?P<em>[^*]+)\*"
    r"|\[(?P<label>[^\]]+)\]\((?P<href>[^)\s]+)\)"
)


def tokenize(text):
    """The tokens of one line of text, in order."""
    out = []
    pos = 0
    for match in _PATTERN.finditer(text):
        if match.start() > pos:
            out.append(Token("text", text[pos:match.start()]))
        if match.group("code") is not None:
            out.append(Token("code", match.group("code")))
        elif match.group("strong") is not None:
            out.append(Token("strong", match.group("strong")))
        elif match.group("em") is not None:
            out.append(Token("em", match.group("em")))
        else:
            out.append(Token("link", match.group("label"), match.group("href")))
        pos = match.end()
    if pos < len(text):
        out.append(Token("text", text[pos:]))
    return out
