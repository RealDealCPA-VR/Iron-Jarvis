"""HTML escaping."""


def escape(text):
    """``text`` made safe to put between HTML tags or in an attribute value."""
    return (
        text.replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace('"', "&quot;")
    )
