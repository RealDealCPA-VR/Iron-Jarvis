"""tinylex 0.4 — splits a line of text into inline tokens.

    >>> tinylex.tokenize("a **b** `c`")
    [Token(kind='text', text='a ', href=''), Token(kind='strong', text='b', href=''), Token(kind='text', text=' ', href=''), Token(kind='code', text='c', href='')]

Token kinds: ``text``, ``strong`` (``**b**``), ``em`` (``*e*``), ``code``
(```c```) and ``link`` (``[label](url)``: ``text`` is the label, ``href``
the url).
"""
from ._escape import escape
from ._tokens import Token, tokenize

__version__ = "0.4.2"
__all__ = ["Token", "tokenize", "escape", "__version__"]
